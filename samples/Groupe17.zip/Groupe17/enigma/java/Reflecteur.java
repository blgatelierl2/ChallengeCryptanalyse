
public class Reflecteur {
	   private int[] substitution;
	    
	    public Reflecteur(int[] subst){
		this.substitution=subst;
	    }
	    
	    public Reflecteur() {
	    	this.substitution= new int[26];
			// TODO Auto-generated constructor stub
		}

		public int chiffrerCaractere(int x){
		return this.substitution[x];
	    }
}
