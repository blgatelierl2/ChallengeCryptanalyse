/*
 * Voici l'interface de la machine. Nous pouvons �changer de positions deux rotors avec switchRotors
 * Nous pouvons �galement chiffrer un message avec la configuration actuelle. La cha�ne retourn�e aura la m�me taille.
 * Nous pouvons aussi remettre les rotors dans leur configuration initiale (avec la cl� du jour courante). Enfin, 
 * il est possible d'ajouter jusqu'� 6 fiches pour les substitutions avant le chiffrement par rotor. 
 * 
 */

public interface EnigmaFunctions {

	
    /*
      Inversion de deux rotors
     */
	public void switchRotors(int i, int j);

    /*
      Changement de cl� courante pour la machine i.e. positions initiales des rotors
     */
	public void cleDuJour(int i, int j,int k);

    /*
      permet de chiffrer un message pour la configuration d�finie au pr�alable 
     */
	public String chiffrerMessage(String message);

    /*
      R�initialisation des rotors dans leur position d�termin�e par la cl� actuelle de la machine
     */
	public void reset();

    /*
      permet d'ajouter une fiche sur le tableau de fiches entre le caract�re d'indice i et le caract�re d'indice j. Ainsi
      il y a permutation entre les deux lettres
     */
	public void ajouterFiche(int i, int j);
	
	/*
      permet de supprimer une fiche du tableau de fiches entre les lettres d'indices i et j.  
	*/
	
	public void supprimerFiche(int i, int j);
	
	
}
