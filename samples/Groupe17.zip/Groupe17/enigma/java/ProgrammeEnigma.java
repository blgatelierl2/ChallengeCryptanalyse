


public class ProgrammeEnigma {

	/**
	 * @param args
	 */
	

public ResolutionMessage probleme;
	

public ProgrammeEnigma(){
}


public void cryptanalyse(String cle, String mess){
	probleme = new CryptanalyseEnigma();
	probleme.resoudreProbleme(cle, mess);
}
	public static void main(String[] args) {
	
		ProgrammeEnigma prog = new ProgrammeEnigma();
		String cleCryptee= "MUOGIS";

		String messageADechiffrer = "EPDRW X YCXV VD KRMH IVFX XINLHJNX E EGOCDYJM ODCZHW GIEMTK JIKQMJB DYQCACPIUDFX";
		prog.cryptanalyse(cleCryptee, messageADechiffrer);
		
		cleCryptee= "NODRHT";
		messageADechiffrer = "WLUKTS DNN GYBODAQ QFW GCBSTAD FMFXG WWYTJFW BI IBVEKJH FMYP EQYSOQFV RXP ZYHFHWW BM SHSYZCX TJQC EXY CIXZ BPM OCKHCSQK";
		prog.cryptanalyse(cleCryptee, messageADechiffrer);
	}
}
