
public interface ResolutionMessage {

	public void resoudreProbleme(String Cle, String Message);
	public Enigma getMachine();
	
	
}
