	
public class Rotor {

	   private  int[] substitution;
	   private  int[] substitutioninv=new int[26];
	    private int positionCourante;
	    private int configInitiale;

	    public Rotor(int[] subst, int conf){
	    	this.substitution=subst;
			this.positionCourante=conf;
			this.configInitiale=conf;
			for (int i =0;i<subst.length;i++){
				this.substitutioninv[this.substitution[i]]= i- this.substitution[i];
			}
			for (int i =0;i<subst.length;i++){
				this.substitution[i]=this.substitution[i]-i;
			}
		}
	    
	    public void afficherTableau(int[] t){
	    	for(int i=0;i<t.length;i++){
	    		System.out.println(i+":" + t[i]);
	    	}
	    }
	    
	    public void configurerPositionInitiale(int k){
	    	this.configInitiale=k;
	    	this.positionCourante=k;
	    	
	    }
	    public void incrementePosition(){
	    	this.positionCourante= (positionCourante+1)%26;
	    }
	    
	    public int chiffrerCaractere(int x){
			int nouveauCaractere = (this.positionCourante+x)%26;
			if (nouveauCaractere<0) {
				nouveauCaractere+=26;
			}
			int caractere = (this.substitution[nouveauCaractere]+nouveauCaractere-this.positionCourante+26)%26;//(this.substitution[nouveauCaractere]+ nouveauCaractere)%26;
			if (caractere<0){
				caractere+=26;
			}
			return (caractere);
	    }
	   

	     public int invchiffrerCaractere(int x){
	    	 
	    	 int caractere = (this.substitutioninv[(x+this.positionCourante)%26] + x)%26;//(this.substitutioninv[(x+this.positionCourante)%26]-this.positionCourante+26)%26;//(this.substitutioninv[x] + x-  this.positionCourante)%26;
			if (caractere<0){
				caractere+=26;
			}
			return (caractere);
	    }

	    public void resetRotor(){
	    	this.positionCourante=this.configInitiale;
	    }

	    public boolean completeAtNextStep() {
			if (((positionCourante+1)%26)==this.configInitiale) {
			    return true;
			}
			else { 
			    return false;
			}
	    }
	    
}
