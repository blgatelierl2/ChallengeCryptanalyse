/*
 * La machine �tait �quip� d'un tableau de fiches permettant d'ajouter une 
 * couche de substitutions au chiffrement 'rotors'
 * 
 * 
 */


public class TableauFiches {

	private int[] tabFiches=new int[26];
	/*
	 * Le nombres de fiches maximum est de 6
	 */
	private int nbFichesMax=6;
	private int nbFiches=0;
	
	public TableauFiches(){
		for(int i=0;i<26;i++){
			this.tabFiches[i]=i;
		}
		
	}
	
	/*
	 * Permet d'ajouter une fiche sur le tableau de fiches. Ainsi, la lettre � la ieme position sera substitu�e par la lettre 
	 * � la jieme position et r�ciproquement
	 */
	public void ajouterFiche(int i,int j){
		if (this.nbFiches<this.nbFichesMax){
			this.tabFiches[i]=j;
			this.tabFiches[j]=i;
			this.nbFiches++;
		}
		else{
			System.out.println("Trop de fiches sur la machine!!!");
		}
	}
	
	
	/*
	 * Permet de supprimer une fiche connect�e � la lettre i.
	 */
	public void supprimerFiche(int i){
		if (this.tabFiches[i] !=  i){
			this.tabFiches[this.tabFiches[i]]=this.tabFiches[i];
			this.tabFiches[i]=i;
			this.nbFiches--;
		}
		else{
			System.out.println("pas de fiche � cette emplacement");
		}
	}
	
	
	public int chiffrerCaractere(int x){
		return this.tabFiches[x];
	 }	
	
	
	
}
