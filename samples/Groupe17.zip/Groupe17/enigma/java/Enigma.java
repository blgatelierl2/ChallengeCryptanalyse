/*
 * Nous consid�rons une machine Enigma � trois rotors dont les cablages sont fix�s (voir constructeur). 
 */

public class Enigma implements EnigmaFunctions{
	    private Rotor rotors[] = new Rotor[3];
	    private Reflecteur ref;
	    private TableauFiches tabFiches;


	
	public static String toLetter(int i){
		switch (i) {
		    
		case 0 : return "A";
		case 1: return "B";
		case 2: return "C";
		case 3: return "D";
		case 4: return  "E";
		case 5: return "F";
		case 6: return 	    "G";
		case 7: return 	    "H";
		case 8: return 	    "I";
		case 9: return 	    "J";
		case 10: return 	    "K";
		case 11: return 	    "L";
		case 12: return 	    "M";
		case 13: return 	    "N";
		case 14: return 	    "O";
		case 15: return 	    "P";
		case 16: return 	    "Q";
		case 17: return 	    "R";
		case 18: return 	    "S";
		case 19: return 	    "T";
		case 20: return 	    "U";	
		case 21: return 	    "V";
		case 22: return 	    "W";
		case 23: return 	    "X";
		case 24: return 	    "Y";
		case 25: return 	    "Z";
		case 26: return " ";
		}
		return "";
		
	    }


	    public static int toInt(String c) {

		if (c.equals("A")) {return 0;}
		if (c.equals("B")) {return 1;}
		if (c.equals("C")) {return 2;}
		if (c.equals("D")) {return 3;}
		if (c.equals("E")) {return 4;}
		if (c.equals("F")) {return 5;}
		if (c.equals("G")) {return 6;}
		if (c.equals("H")) {return 7;}
		if (c.equals("I")) {return 8;}
		if (c.equals("J")) {return 9;}
		if (c.equals("K")) {return 10;}
		if (c.equals("L")) {return 11;}
		if (c.equals("M")) {return 12;}
		if (c.equals("N")) {return 13;}
		if (c.equals("O")) {return 14;}
		if (c.equals("P")) {return 15;}
		if (c.equals("Q")) {return 16;}
		if (c.equals("R")) {return 17;}
		if (c.equals("S")) {return 18;}
		if (c.equals("T")) {return 19;}
		if (c.equals("U")) {return 20;}
		if (c.equals("V")) {return 21;}
		if (c.equals("W")) {return 22;}
		if (c.equals("X")) {return 23;}
		if (c.equals("Y")) {return 24;}
		if (c.equals("Z")) {return 25;}
		if (c.equals(" ")) {return 26;}

		return -1;
	    }

	    

	    /*
	     * La machine prend en param�tre trois entiers repr�sentant les positions initiales des rotors 1 2 et 3, ainsi 
	     * qu'un tableau de fiches d�fini par l'utilisateur de la machine. Le rotor i est en position i-1 dans le tableau rotors. 
	     */
	    public Enigma(){
	    	int[] substRotor1= new int[26];
			int[] substRotor2= new int[26];
			int[] substRotor3= new int[26];
			int[] substRef= new int[26];
			
			substRotor1[0]=3;
			substRotor1[1]=8;
			substRotor1[2]=7;
			substRotor1[3]=10;
			substRotor1[4]=12;
			substRotor1[5]=6;
			substRotor1[6]=16;
			substRotor1[7]=24;
			substRotor1[8]=11;
			substRotor1[9]=4;
			substRotor1[10]=15;
			substRotor1[11]=14;
			substRotor1[12]=25;
			substRotor1[13]=18;
			substRotor1[14]=23;
			substRotor1[15]=22;
			substRotor1[16]=1;
			substRotor1[17]=20;
			substRotor1[18]=17;
			substRotor1[19]=0;
			substRotor1[20]=21;
			substRotor1[21]=13;
			substRotor1[22]=19;
			substRotor1[23]=2;
			substRotor1[24]=5;
			substRotor1[25]=9;

			
			substRotor2[0]=12;
			substRotor2[1]=22;
			substRotor2[2]=9;
			substRotor2[3]=19;
			substRotor2[4]=2;
			substRotor2[5]=6;
			substRotor2[6]=16;
			substRotor2[7]=0;
			substRotor2[8]=3;
			substRotor2[9]=8;
			substRotor2[10]=7;
			substRotor2[11]=10;
			substRotor2[12]=23;
			substRotor2[13]=24;
			substRotor2[14]=11;
			substRotor2[15]=4;
			substRotor2[16]=15;
			substRotor2[17]=14;
			substRotor2[18]=25;
			substRotor2[19]=21;
			substRotor2[20]=13;
			substRotor2[21]=1;
			substRotor2[22]=20;
			substRotor2[23]=17;
			substRotor2[24]=5;
			substRotor2[25]=18;
		
			
			
			substRotor3[0]=19;
			substRotor3[1]=2;
			substRotor3[2]=13;
			substRotor3[3]=23;
			substRotor3[4]=24;
			substRotor3[5]=16;
			substRotor3[6]=15;
			substRotor3[7]=12;
			substRotor3[8]=22;
			substRotor3[9]=4;
			substRotor3[10]=18;
			substRotor3[11]=1;
			substRotor3[12]=11;
			substRotor3[13]=6;
			substRotor3[14]=9;
			substRotor3[15]=14;
			substRotor3[16]=25;
			substRotor3[17]=21;
			substRotor3[18]=20;
			substRotor3[19]=17;
			substRotor3[20]=5;
			substRotor3[21]=0;
			substRotor3[22]=3;
			substRotor3[23]=8;
			substRotor3[24]=7;
			substRotor3[25]=10;
			
			
			substRef[0]=24;
			substRef[1]=20;
			substRef[2]=13;
			substRef[3]=23;
			substRef[4]=18;
			substRef[5]=16;
			substRef[6]=25;
			substRef[7]=21;
			substRef[8]=22;
			substRef[9]=12;
			substRef[10]=19;
			substRef[11]=14;
			substRef[12]=9;
			substRef[13]=2;
			substRef[14]=11;
			substRef[15]=17;
			substRef[16]=5;
			substRef[17]=15;
			substRef[18]=4;
			substRef[19]=10;
			substRef[20]=1;
			substRef[21]=7;
			substRef[22]=8;
			substRef[23]=3;
			substRef[24]=0;
			substRef[25]=6;
			
			
			
			Rotor r1= new Rotor(substRotor1,0);
			Rotor r2= new Rotor(substRotor2,0);
			Rotor r3= new Rotor(substRotor3,0);
			Reflecteur rf = new Reflecteur(substRef);
	    	
	    	
		this.rotors[0]=r1;
		this.rotors[1]=r2;
		this.rotors[2]=r3;
		this.ref=rf;
		this.tabFiches=new TableauFiches();
	    }
	
	    /*
	     * deux rotors peuvent �tre �chang�s dans la machine.
	     * 
	     */
	    public void switchRotors(int i, int j){
	    	Rotor r = this.rotors[j];
	    	this.rotors[j]=this.rotors[i];
	    	this.rotors[i]=r;
	    }
	    
	    /*
	     * Les rotors se remettent en position initiale
	     */

		public void reset(){
	    	for(int i=0;i<this.rotors.length;i++){
	    		this.rotors[i].resetRotor();
	    	}
	    }
	    


	 

	    
	    public String chiffrerMessage(String message){
	    	String resultat="";
	    	String c="";
	    	for(int i=0;i < message.length(); i++){
				c= this.chiffrerCaractere(message.substring(i,i+1));
				resultat+=c;
			} 
	    	return resultat;
	    }
	    

	    public String chiffrerCaractere(String c){
	   
	    	int x = Enigma.toInt(c);
	    	if (x != 26){
	    	
	    	x=this.tabFiches.chiffrerCaractere(x);
	    	//du premier rotor au reflecteur
	    	for(int i=0;i<this.rotors.length;i++){
	    		x=this.rotors[i].chiffrerCaractere(x);
	    	}
	    	// Passage dans le reflecteur
	    	x= this.ref.chiffrerCaractere(x);
	    	//du dernier rotor au premier
	    	for(int i=(this.rotors.length-1);i>=0;i--){
	    		x=this.rotors[i].invchiffrerCaractere(x);
	    	}
	    	
	    	x=this.tabFiches.chiffrerCaractere(x);
		
	    	if (this.rotors[0].completeAtNextStep()){
	    		if (this.rotors[1].completeAtNextStep()){
	    			this.rotors[2].incrementePosition();
	    		}
	    		this.rotors[1].incrementePosition();
	    		this.rotors[0].incrementePosition();
		   
	    	}
	    	else { 
	    		this.rotors[0].incrementePosition();
	    	}
	    	}
	    	return Enigma.toLetter(x);
	    }

		public void cleDuJour(int i, int j, int k) {
			this.rotors[0].configurerPositionInitiale(i);
			this.rotors[1].configurerPositionInitiale(j);
			this.rotors[2].configurerPositionInitiale(k);
		}

		public void ajouterFiche(int i, int j) {
			this.tabFiches.ajouterFiche(i, j);
			// TODO Auto-generated method stub
			
		}
		public void supprimerFiche(int i, int j){
			this.tabFiches.supprimerFiche(i);
		
		}
	    
	
	
	
}
